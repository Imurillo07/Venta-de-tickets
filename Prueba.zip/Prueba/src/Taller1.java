package Semana4;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author isaac
 */
public class Taller1 {
    public static void main (String[] ijmm){
        Set<Integer> valores = new HashSet<Integer>();
        
        valores.add(3);
        valores.add(7);
        valores.add(39);
        valores.add(23);
        valores.add(74);
        valores.add(56);
        valores.add(41);
        valores.add(7);
        valores.add(94);
        valores.add(82);
        
        for (int elemento: valores){
            System.out.print(elemento+"-");
        }
        System.out.println();
    }
}