package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class ProTickets {
    public static void main (String [] args){
        System.out.println("---------------BIENVENIDOS---------------"
                + "\n---------------A ProTicket---------------"
                + "\n------------------MENU-------------------");
        
    }
}
 