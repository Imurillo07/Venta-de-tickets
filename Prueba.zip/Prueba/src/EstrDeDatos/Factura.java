package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class Factura {
    
}
