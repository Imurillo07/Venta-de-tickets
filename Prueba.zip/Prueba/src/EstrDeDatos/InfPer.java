package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class InfPer{
    
}
