package proyecto;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// version de Ximena 

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** ULACIT
 * @author ximena perez, isaac murillo, caroline chaves 
 */
        
public class jimena {
    public static void main (String [] xxpj){
        
        Scanner sc = new Scanner(System.in);
        Scanner EscXTeclado = new Scanner(System.in);
        
        System.out.println("");
        System.out.println("------------------------------------------------------------------------------------------------");
        System.out.println("");
        System.out.println("\t---------BIENVENIDOS A LA ZAPATERIA CIX---------");
        System.out.println("");
        System.out.println("-------------------------------------------------------------------------------------------------");

        //VARIABLES
        float opcionn=0;
        int opcion = 0;
        int prodInv=0;
        float totFact=0;
        int pAdidasC=0;
        int pTenisC=0;
        int pSandaliasC=0;
        int pConverseC=0;
        int adidas=35;
        int tenisNegro=54;
        int sandalias=15;
        int converse=29;
        List<String> listaNom = new ArrayList<String>();
        int yy =1;

        while (yy<2){
            System.out.println("-----------------------------------------");
            System.out.println("\tMENU PRINCIPAL");
            System.out.println("");
            System.out.println("1. Realizar compra");
            System.out.println("2. Disponibilidad de productos e inventario");
            System.out.println("3. Cierre de caja");
            System.out.println("4. Salir");
            System.out.println("Digite el numero de la opcion que desea: ");
            opcionn = sc.nextInt();
            System.out.println("-----------------------------------------");
            
            //VARIABLES DEL LOOP
            
            String nombre="";
            String apellido="";
            String provincia="";
            String cedula="";
            int cantZap=0;
            int xx = 1;
            int prod=0;
            int ww=0;
            int factAdidas=0;
            int factTenis=0;
            int factSandalias=0;
            int factConverse=0;
            int pAdidas=60;
            int pTenis=35;
            int pSandalias=22;
            int pConverse= 76;
            int totAdidas=0;
            int totTenis=0;
            int totSandalias=0;
            int totConverse=0;
            int day=0;
           

            if (opcionn==1){
                System.out.println("Ha seleccionado la opcion 1");
                System.out.println("-----------------------------------------");
                System.out.println("-----Datos del cliente-----");
                System.out.println("Favor ingresar datos de cliente");
                System.out.println("-----------------------------------------");
                System.out.println("Ingrese el nombre: ");
                nombre = EscXTeclado.nextLine();
                listaNom.add(nombre);
                

                System.out.println("Ingrese el apellido: ");
                apellido=EscXTeclado.nextLine();      

                System.out.println("Ingrese la provincia en la que vive: ");
                provincia = EscXTeclado.nextLine();


                System.out.println("Ingrese la cedula: ");
                cedula = EscXTeclado.nextLine();

                System.out.println("");
                System.out.println("Lista de clientes: "+listaNom);
                System.out.println("");
                System.out.println("\t-----PRODUCTOS-----");
                while (ww<5){
                int canAdidas=0;
                int canTenis=0;
                int canSandalias=0;
                int canConverse=0;
                System.out.println("PRODUCTOS: 1.Adidas($60), 2.Tenis negro($35), 3.Sandalias($22), 4.Converse($76), 5.NO desea mas productos");
                prod=sc.nextInt();
                if (prod==1){
                    System.out.println("Cantidad de Adidas disponibles....."+adidas);
                    System.out.println("Digite la cantidad de pares de Adidas que desea: ");
                    canAdidas= sc.nextInt(); 
                    adidas=adidas-canAdidas;
                    factAdidas=factAdidas+canAdidas;
                    totAdidas=totAdidas+(factAdidas*pAdidas);
                    totFact=totFact+totAdidas;
                    pAdidasC=pAdidasC+factAdidas;
                    
                }
                if (prod==2){
                    System.out.println("Cantidad de Tenis negro disponibles....."+tenisNegro);
                    System.out.println("Digite la cantidad de pares de Tenis negro que desea: ");
                    canTenis= sc.nextInt(); 
                    tenisNegro=tenisNegro-canTenis;
                    factTenis=factTenis+canTenis;
                    totTenis=totTenis+(factTenis*pTenis);
                    totFact=totFact+totTenis;
                    pTenisC=pTenisC+factTenis;
                    
                }
                if (prod==3){
                    System.out.println("Cantidad de sandalias disponibles....."+sandalias);
                    System.out.println("Digite la cantidad de pares de Sandalias que desea: ");
                    canSandalias= sc.nextInt(); 
                    sandalias=sandalias-canSandalias;
                    factSandalias=factSandalias+canSandalias;
                    totSandalias=totSandalias+(factSandalias*pSandalias);
                    totFact=totFact+totSandalias;
                    pSandaliasC=pSandaliasC+factSandalias;
                    
                }
                if (prod==4){
                    System.out.println("Cantidad de converse disponibles....."+converse);
                    System.out.println("Digite la cantidad de pares de converse que desea: ");
                    canConverse= sc.nextInt(); 
                    converse=converse-canConverse;
                    factConverse=factConverse+canConverse;
                    totConverse=totConverse+(factConverse*pConverse);
                    totFact=totFact+totConverse;
                    pConverseC=pConverseC+factConverse;
                    
                }
                if (prod>=5){
                    System.out.println("------------------------------------------");
                    ww=8;
                }
                
                
                
                }
                
                 
                System.out.println("");
                System.out.println("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
                System.out.println("\t---------------FACTURACION----------------");
                System.out.println("");
                System.out.println("DATOS CLIENTE:-----------------------");
                System.out.println("Nombre: " + nombre);
                System.out.println("Apellido: " + apellido);
                System.out.println("Cedula: " + cedula);
                System.out.println("Provincia: "+ provincia);
                System.out.println("");
                System.out.println("");
                System.out.println("PRODUCTOS:---------------------------");
                System.out.println("Adidas compradas ($60) : " +factAdidas+"......total Adidas: $"+totAdidas);
                System.out.println("Tenis negro comprados ($35) : "+factTenis+".......total Tenis negro: $"+totTenis);
                System.out.println("Sandalias compradas ($22) : "+factSandalias+".......total Sandalias: $"+totSandalias);
                System.out.println("Converse comprados ($76) : "+factConverse+".......total COnverse: $"+totConverse);
                System.out.println("TOTAL: $" +(totAdidas+totTenis+totSandalias+totConverse));
                System.out.println("");
                System.out.println("/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
                
                
            }
//-------------------------------------------------------INVENTARIO--------------------------------------------------------------------------------------------------------

            if (opcionn==2){
                System.out.println("Ha seleccionado la opcion de disponibilidad e inventario");
                System.out.println("-----------------------------------------");
                System.out.println("");

                //listas
                
                while (xx<2){
                    //menu entrada
                    opcion = 0;

                    System.out.println("-----------------------");
                    System.out.println("");
                    System.out.println("Que desea hacer (#)?");
                    System.out.println("1. Ver inventario");
                    System.out.println("2. Editar inventario");
                    System.out.println("3. Volver al menu");
                    System.out.println("-----------------------");
                    opcion = sc.nextInt();
                    if (opcion==3){
                        xx=4;
                        break;
                    }
                    if (opcion == 1) {
                        System.out.println("Adidas: "+adidas);
                        System.out.println("Tenis negros: "+tenisNegro);
                        System.out.println("Sandalias: "+sandalias);
                        System.out.println("Converse: "+converse);
                    }
                    if (opcion == 2) {
                        System.out.println("PRODUCTOS: 1.Adidas, 2.Tenis negro, 3.Sandalias, 4.Converse");
                        System.out.println("Digite el numero del producto que desea editar: ");
                        prodInv = sc.nextInt();
                        
                        if (prodInv==1){
                            int opEdit=0;
                            System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                            opEdit = sc.nextInt();
                            
                            if (opEdit==1){
                                System.out.println("Digite la cantidad de productos que desee agregar: ");
                                cantZap =sc.nextInt();
                                adidas=adidas+cantZap;
                            }
                            
                            if (opEdit==2){
                                System.out.println("Digite la cantidad de productos que desea quitar: ");
                                cantZap= sc.nextInt();
                                adidas=adidas-cantZap;
                            }
                            
                        } 
                        
                        if (prodInv==2){
                            int opEdit=0;
                            System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                            opEdit = sc.nextInt();
                            
                            if (opEdit==1){
                                System.out.println("Digite la cantidad de productos que desee agregar: ");
                                cantZap =sc.nextInt();
                                tenisNegro=tenisNegro+cantZap;
                            }
                            
                            if (opEdit==2){
                                System.out.println("Digite la cantidad de productos que desea quitar: ");
                                cantZap= sc.nextInt();
                                tenisNegro=tenisNegro-cantZap;
                            }
                            
                        } 
                        
                        if (prodInv==3){
                            int opEdit=0;
                            System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                            opEdit = sc.nextInt();
                            
                            if (opEdit==1){
                                System.out.println("Digite la cantidad de productos que desee agregar: ");
                                cantZap =sc.nextInt();
                                sandalias=sandalias+cantZap;
                            }
                            
                            if (opEdit==2){
                                System.out.println("Digite la cantidad de productos que desea quitar: ");
                                cantZap= sc.nextInt();
                                sandalias=sandalias-cantZap;
                            }
                            
                        } 
                        
                        if (prodInv==4){
                            int opEdit=0;
                            System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                            opEdit = sc.nextInt();
                            
                            if (opEdit==1){
                                System.out.println("Digite la cantidad de productos que desee agregar: ");
                                cantZap =sc.nextInt();
                                converse=converse+cantZap;
                            }
                            
                            if (opEdit==2){
                                System.out.println("Digite la cantidad de productos que desea quitar: ");
                                cantZap= sc.nextInt();
                                converse=converse-cantZap;
                            }
                                 else {
                        
                    }
                            
                        }
                   
                    else{
                        
                    }
                    }
                }
                    
            }
        
            
//----------------------------------------------------------cierre de caja-------------------------------------------------------------------------------------------------------
            if (opcionn==3){
                System.out.println("Ha seleccionado la opcion de revision de caja");
                System.out.println("////////////////////////////////////////////////////////////////////");
                System.out.println("");
                System.out.println("LISTA DE CLIENTES: " +listaNom);
                System.out.println("");
                System.out.println("-------------------------------------------------------------------");

                System.out.println("TODOS LOS PRODUCTOS VENDIDOS EN EL DIA");
                System.out.println("");
                System.out.println("Cantidad de pares de Adidas vendidas: "+pAdidasC);
                System.out.println("Ingresos por los pares de Adidas vendidos: $"+(pAdidasC*60));
                System.out.println("");
                System.out.println("Cantidad de pares de Tenis negro vendidas: "+pTenisC);
                System.out.println("Ingresos por los pares de Tenis negro vendidos: $"+(pTenisC*35));
                System.out.println("");
                System.out.println("Cantidad de pares de Sandalias vendidas: "+pSandaliasC);
                System.out.println("Ingresos por los pares de Sandalias vendidos: $"+(pSandaliasC*22));
                System.out.println("");
                System.out.println("Cantidad de pares de Converse vendidas: "+pConverseC);
                System.out.println("Ingresos por los pares de Converse vendidos: $"+(pConverseC*76));
                System.out.println("");
                
                
                System.out.println("-------------------------------------------------------------------------");
                System.out.println("GANANCIAS DEL DIA");
                System.out.println("El ingreso total del dia fue de: $"+totFact);
                System.out.println("");
                System.out.println("-------------------------------------------------------------------");
                System.out.println("CANTIDAD DE PRODUCTOS RESTANTES");
                System.out.println("Adidas: "+adidas);
                System.out.println("Tenis negro: "+tenisNegro);
                System.out.println("Sandalias: "+sandalias);
                System.out.println("Converse: "+converse);
                System.out.println("//////////////////////////////////////////////////////////////////////");
                System.out.println("Desea reiniciar el dia?--1.Si--2.No--");
                System.out.println("Digite el numero de la opcion que desee");
                day=sc.nextInt();
                if (day==1){
                    listaNom.clear();
                    pAdidasC=0;
                    pTenisC=0;
                    pSandaliasC=0;
                    pConverseC=0;
                    totFact=0;
                    
                }
                if (day==2){
                    
                }
                        
            }
//--------------------------------------------------------------------------------------------------------------------------------------------------------------
           

            if (opcionn==4){
                System.out.println("Se ha finalizado el sistema");
                System.out.println("-----------------------------------------");
                break;
                //salir de sistema

            }

            else{
                
                System.out.println("-----------------------------------------");
            }
        

    
        }


 }
}