package proyecto;

/**
 *
 * @author isaac
 */
import java.util.ArrayList; 
import java.util.List; 
import java.util.Scanner;

public class AnadirProductos {
    //teclado 

    Scanner sc = new Scanner (System.in); 

    Scanner EscXTeclado = new Scanner(System.in);
        
    public static void main (String[]ijmm){
        
        //teclado
        Scanner sc = new Scanner (System.in);
        
        //listas
        List<String> productos = new ArrayList<>();
        
       //variable
       
       int opcion = 0;
       boolean x = true;
       
        while (x){
            //menu entrada
            opcion = 0;
           
            System.out.println("-----------------------");
            System.out.println("Que desea hacer?");
            System.out.println("1. Ingresar el producto y su catidad respectiva de invenatrio");
            System.out.println("2. sumar o restar inventario");
            System.out.println("3. ver inventario");
            System.out.println("4. volver al menu");
            System.out.println("-----------------------");
            opcion = Integer.parseInt(sc.nextLine());
           
            
            switch (opcion){
                case 1:
                    AnadirProductos.ingresarProductosYCantidad(productos);
                    //opcion = Integer.parseInt(sc.nextLine());
                    break;
                  
                case 2:
                    AnadirProductos.SumaRestaInv(productos);
                    //opcion = Integer.parseInt(sc.nextLine());
                    break;
                 
                case 3: 
                    AnadirProductos.VerInv(productos);
                    //opcion = Integer.parseInt(sc.nextLine());
                    break;
                    
                case 4: 
                    x = false;
                    
            }
        }
            
    }//fin public static void main                
        
        
        
    public static List<String> ingresarProductosYCantidad(List<String> productos ){
         // variables  

        String nuevoprod = "";
        boolean ciclo = true;
        int repetir = 0;
        //boolean ciclo2 = true;

        //listas
        //List<String> productos = new ArrayList<>();
        

        //teclado
        Scanner sc = new Scanner (System.in); 

        //pedir detalles del producto
        while (ciclo == true){
            System.out.println("-----------------------"); 
            System.out.println("Ingrese el modelo y la cantidad de este"); 
            System.out.println("Ejemplo: adidas=10");
            nuevoprod = sc.nextLine();
            System.out.println("-----------------------");
            productos.add(nuevoprod);
            nuevoprod = "";
            System.out.println(productos);
            System.out.println("-----------------------");
            System.out.println("Desea anadir otro producto?");
            System.out.println("1.Si o 2.No");
            System.out.println("SOLO PONER NUMERO");
            repetir = sc.nextInt();
            System.out.println("-----------------------");
            //switch para ver si repetimos ciclo
            if (repetir == 1){
                System.out.println("Anadir nuevo producto");
                nuevoprod = sc.nextLine();
            }else{
                ciclo = false;
            }
            
        }//fin while ciclo
        
        System.out.println("Los nuevos productos han sido anadidos correctamente  ");
        return productos;
        
    }//fin del metodo ingresarProductosYCantidad
    
    public static List<String> SumaRestaInv(List<String> productos){
        
        //teclado 
        Scanner sc = new Scanner (System.in);
        Scanner EscXTeclado = new Scanner(System.in);
        
        //variables
        int valor = 0;
        String actualizar = "";
        int repetir2 = 0;
        boolean ciclo2 = true;
        
        //lista
        //AnadirProductos.ingresarProductosYCantidad(productos);
        
        
        //intrucciones
        while (ciclo2 == true){
            System.out.println("-----------------------");
            System.out.println("Los prodcutos van oredenados del 0 en adelante.");
            System.out.println("Si uested desea cambiar el primer prodcuto en pantalla,estaria cambiando el valor 0");
            System.out.println("-----------------------");
            System.out.println("Imprimiendo Inventario");
            System.out.println(productos);
            System.out.println("-----------------------");
            System.out.println("Cual valor desea editar?");
            System.out.println("Recuerde poner SOLO NUMEROS");
            valor = EscXTeclado.nextInt();
            System.out.println("-----------------------");
            System.out.println("Poner la nueva informacion del producto.");
            actualizar = sc.nextLine();
            productos.set(valor, actualizar);
            System.out.println("Actualizando Lista");
            System.out.println("-----------------------");
            System.out.println("La lista ha sido actualizada correctamente.");
            System.out.println(productos);
            System.out.println("-----------------------");
            System.out.println("Desea editar otro producto?");
            System.out.println("1.Si o 2.No");
            System.out.println("SOLO PONER NUMERO");
            repetir2 = sc.nextInt();
            if (repetir2 == 1){
                valor = EscXTeclado.nextInt();
                actualizar = sc.nextLine();
                repetir2 = sc.nextInt();
            }else{
                ciclo2 = false;
            }
            
        }//fin while ciclo2
        
        return productos;
    }//fin metodo SumaRestaInv
    
    public static void VerInv(List<String>productos){
        System.out.println("-----------------------");
        System.out.println("Imprimiendo Inventario");
        System.out.println(productos);
    }//fin metodo VerInv
    
}//fin public class AnadirProductos

