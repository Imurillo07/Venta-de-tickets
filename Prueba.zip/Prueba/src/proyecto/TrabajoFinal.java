package proyecto;

/** ULACIT
 * @author ximena perez, isaac murillo, caroline chaves 
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TrabajoFinal {
    
    static int factAdidas=0;
    static int factTenis=0;
    static int factSandalias=0;
    static int factConverse=0;
    static int pAdidas=60;
    static int pTenis=35;
    static int pSandalias=22;
    static int pConverse= 76;
    static int totAdidas=0;
    static int totTenis=0;
    static int totSandalias=0;
    static int totConverse=0;
    static float totFact=0;
    static int pAdidasC=0;
    static int pTenisC=0;
    static int pSandaliasC=0;
    static int pConverseC=0;
    static int adidas=35;
    static int tenisNegro=54;
    static int sandalias=15;
    static int converse=29;
    
    public static void main (String [] gcix){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("------------------------------------------------------------------------------------------------");
        System.out.println("");
        System.out.println("\t---------BIENVENIDOS A LA ZAPATERIA CIX---------");
        System.out.println("");
        System.out.println("-------------------------------------------------------------------------");

        //VARIABLES
        int opcionn=0;
        
        List<String> listaNom = new ArrayList<String>();
        int yy =1;
        
        

        while (yy<2){
            System.out.println("-------------------------------------------------------------------------");
            System.out.println("\tMENU PRINCIPAL");
            System.out.println("");
            System.out.println("1. Realizar compra");
            System.out.println("2. Disponibilidad de productos e inventario");
            System.out.println("3. Cierre de caja");
            System.out.println("4. Salir");
            System.out.println("Digite el numero de la opcion que desea: ");
            opcionn = sc.nextInt();
            System.out.println("-------------------------------------------------------------------------");

            switch(opcionn){
                case 1:
                    TrabajoFinal.Compra(listaNom);
                    break;
              
                case 2:
                    TrabajoFinal.Inventario();
                    break;   
                    
                case 3:
                    TrabajoFinal.CierreCaja(listaNom);
                    break;
                    
                case 4:
                    System.out.println("Se ha finalizado el sistema");
                    System.out.println("-------------------------------------------------------------------------");
                    break;   
            }  
            
        }//final while yy<2    
    }//FINAL METODO MAIN

    public static List<String> Compra(List<String>listaNom){
        
        //VARIABLES DEL LOOP
        String nombre = "";
        String apellido = "";
        String provincia = "";
        String cedula = "";        
        int prod = 0;
        int ww = 0;
        
        
        //teclado
        Scanner sc = new Scanner(System.in);
        Scanner EscXTeclado = new Scanner(System.in);
        
        System.out.println("Ha seleccionado la opcion 1");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("-----Datos del cliente-----");
        System.out.println("Favor ingresar datos de cliente");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("Ingrese el nombre: ");
        nombre = EscXTeclado.nextLine();
        listaNom.add(nombre);


        System.out.println("Ingrese el apellido: ");
        apellido=EscXTeclado.nextLine();      

        System.out.println("Ingrese la provincia en la que vive: ");
        provincia = EscXTeclado.nextLine();

        System.out.println("Ingrese la cedula: ");
        cedula = EscXTeclado.nextLine();

        System.out.println("Lista de clientes: "+listaNom);
        System.out.println("\t-----PRODUCTOS-----");
        while (ww<5){
            int canAdidas=0;
            int canTenis=0;
            int canSandalias=0;
            int canConverse=0;
            System.out.println("PRODUCTOS: 1.Adidas($60), 2.Tenis negro($35), 3.Sandalias($22), 4.Converse($76), 5.NO desea mas productos");
            prod=sc.nextInt();
            switch (prod) {
                case 1:
                    System.out.println("Cantidad de Adidas disponibles....."+adidas);
                    System.out.println("Digite la cantidad de pares de Adidas que desea: ");
                    canAdidas= sc.nextInt();
                    adidas = adidas-canAdidas;
                    factAdidas = factAdidas+canAdidas;
                    totAdidas = totAdidas+(factAdidas*pAdidas);
                    totFact = totFact+totAdidas;
                    pAdidasC = pAdidasC+factAdidas;
                    break;
                case 2:
                    System.out.println("Cantidad de Tenis negro disponibles....."+tenisNegro);
                    System.out.println("Digite la cantidad de pares de Tenis negro que desea: ");
                    canTenis= sc.nextInt();
                    tenisNegro=tenisNegro-canTenis;
                    factTenis=factTenis+canTenis;
                    totTenis=totTenis+(factTenis*pTenis);
                    totFact=totFact+totTenis;
                    pTenisC=pTenisC+factTenis;
                    break;
                case 3:
                    System.out.println("Cantidad de sandalias disponibles....."+sandalias);
                    System.out.println("Digite la cantidad de pares de Sandalias que desea: ");
                    canSandalias= sc.nextInt();
                    sandalias=sandalias-canSandalias;
                    factSandalias=factSandalias+canSandalias;
                    totSandalias=totSandalias+(factSandalias*pSandalias);
                    totFact=totFact+totSandalias;
                    pSandaliasC=pSandaliasC+factSandalias;
                    break;
                case 4:
                    System.out.println("Cantidad de converse disponibles....."+converse);
                    System.out.println("Digite la cantidad de pares de converse que desea: ");
                    canConverse= sc.nextInt();
                    converse=converse-canConverse;
                    factConverse=factConverse+canConverse;
                    totConverse=totConverse+(factConverse*pConverse);
                    totFact=totFact+totConverse;
                    pConverseC=pConverseC+factConverse;
                    break;
                default:
                    System.out.println("-------------------------------------------------------------------------");
                    ww=8;
                    break;
            }
        }
        System.out.println("");
        System.out.println("///////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        System.out.println("\t---------------FACTURACION----------------");
        System.out.println("DATOS CLIENTE:---------------------------------------------------------");
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Cedula: " + cedula);
        System.out.println("Provincia: "+ provincia);
        System.out.println("PRODUCTOS:--------------------------------------------------------------");
        System.out.println("Adidas compradas ($60) : " +factAdidas+"......total Adidas: $"+totAdidas);
        System.out.println("Tenis negro comprados ($35) : "+factTenis+".......total Tenis negro: $"+totTenis);
        System.out.println("Sandalias compradas ($22) : "+factSandalias+".......total Sandalias: $"+totSandalias);
        System.out.println("Converse comprados ($76) : "+factConverse+".......total COnverse: $"+totConverse);
        System.out.println("TOTAL: $" +(totAdidas+totTenis+totSandalias+totConverse));
        System.out.println("/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
                
        return listaNom;
    } //fin metodo compra
    
    public static void Inventario(){
        
        //variables
        int cantZap=0;
        int xx = 1;
        int opcion = 0;
        int prodInv=0;
        int opEdit=0;
        
        
        
        //teclado
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Ha seleccionado la opcion de disponibilidad e inventario");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("");

        //listas

        while (xx<2){
            //menu entrada
            opcion = 0;

            System.out.println("-------------------------------------------------------------------------");
            System.out.println("Que desea hacer (#)?");
            System.out.println("1. Ver inventario");
            System.out.println("2. Editar inventario");
            System.out.println("3. Volver al menu");
            System.out.println("-------------------------------------------------------------------------");
            opcion = sc.nextInt();
            
            if (opcion == 1) {
                System.out.println("Adidas: "+adidas);
                System.out.println("Tenis negros: "+tenisNegro);
                System.out.println("Sandalias: "+sandalias);
                System.out.println("Converse: "+converse);
            }
            else if (opcion == 2) {
                System.out.println("PRODUCTOS: 1.Adidas, 2.Tenis negro, 3.Sandalias, 4.Converse");
                System.out.println("Digite el numero del producto que desea editar: ");
                prodInv = sc.nextInt();
            }
            else if (opcion==3){
                xx=4;
                break;
            }

                switch (prodInv){
                    
                    case 1:    
                        System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                        opEdit = sc.nextInt();

                        if (opEdit==1){
                            System.out.println("Digite la cantidad de productos que desee agregar: ");
                            cantZap =sc.nextInt();
                            adidas=adidas+cantZap;
                            break;
                        }

                        else if (opEdit==2){
                            System.out.println("Digite la cantidad de productos que desea quitar: ");
                            cantZap= sc.nextInt();
                            adidas=adidas-cantZap;
                            break;
                        }
                        
                    case 2:
                        System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                        opEdit = sc.nextInt();

                        if (opEdit==1){
                            System.out.println("Digite la cantidad de productos que desee agregar: ");
                            cantZap =sc.nextInt();
                            tenisNegro=tenisNegro+cantZap;
                            break;
                        }

                        else if (opEdit==2){
                            System.out.println("Digite la cantidad de productos que desea quitar: ");
                            cantZap= sc.nextInt();
                            tenisNegro=tenisNegro-cantZap;
                            break;
                        }

                    case 3:
                        System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                        opEdit = sc.nextInt();

                        if (opEdit==1){
                            System.out.println("Digite la cantidad de productos que desee agregar: ");
                            cantZap =sc.nextInt();
                            sandalias=sandalias+cantZap;
                            break;
                        }

                        else if (opEdit==2){
                            System.out.println("Digite la cantidad de productos que desea quitar: ");
                            cantZap= sc.nextInt();
                            sandalias=sandalias-cantZap;
                            break;
                        }

                    case 4:
                        System.out.println("Digite 1.para agregar y 2.para quitar cantidad de porductos: ");
                        opEdit = sc.nextInt();

                        if (opEdit==1){
                            System.out.println("Digite la cantidad de productos que desee agregar: ");
                            cantZap =sc.nextInt();
                            converse=converse+cantZap;
                            break;
                        }

                        else if (opEdit==2){
                            System.out.println("Digite la cantidad de productos que desea quitar: ");
                            cantZap= sc.nextInt();
                            converse=converse-cantZap;
                            break;
                        }
                }//fin switch 
        }//fin while
    }//fin metodo inventario
    
    public static List<String> CierreCaja(List<String> listaNom){
        
        //var
        int day=0;
        
        //teclado
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Ha seleccionado la opcion de revision de caja");
        System.out.println("////////////////////////////////////////////////////////////////////");
        System.out.println("LISTA DE CLIENTES: " +listaNom);
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("TODOS LOS PRODUCTOS VENDIDOS EN EL DIA");
        System.out.println("Cantidad de pares de Adidas vendidas: "+pAdidasC);
        System.out.println("Ingresos por los pares de Adidas vendidos: $"+(pAdidasC*60));
        System.out.println("Cantidad de pares de Tenis negro vendidas: "+pTenisC);
        System.out.println("Ingresos por los pares de Tenis negro vendidos: $"+(pTenisC*35));
        System.out.println("Cantidad de pares de Sandalias vendidas: "+pSandaliasC);
        System.out.println("Ingresos por los pares de Sandalias vendidos: $"+(pSandaliasC*22));
        System.out.println("Cantidad de pares de Converse vendidas: "+pConverseC);
        System.out.println("Ingresos por los pares de Converse vendidos: $"+(pConverseC*76));


        System.out.println("-------------------------------------------------------------------------");
        System.out.println("GANANCIAS DEL DIA");
        System.out.println("El ingreso total del dia fue de: $"+totFact);
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("CANTIDAD DE PRODUCTOS RESTANTES");
        System.out.println("Adidas: "+adidas);
        System.out.println("Tenis negro: "+tenisNegro);
        System.out.println("Sandalias: "+sandalias);
        System.out.println("Converse: "+converse);
        System.out.println("//////////////////////////////////////////////////////////////////////");
        System.out.println("Desea reiniciar el dia?--1.Si--2.No--");
        System.out.println("Digite el numero de la opcion que desee");
        day=sc.nextInt();
        if (day==1){
            listaNom.clear();
            pAdidasC=0;
            pTenisC=0;
            pSandaliasC=0;
            pConverseC=0;
            totFact=0;

        }
        return listaNom;
    }//fin metodo cierre
        
}//final class
