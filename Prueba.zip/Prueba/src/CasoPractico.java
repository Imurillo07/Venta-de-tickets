import java.util.LinkedList;
import java.util.Stack;
import javax.swing.JOptionPane;


public class CasoPractico {
    
    public static void main (String [] args){
        //variables 
        int respuesta;
        String palabra = "";
        String reversePal = "";
        Boolean x = true;
        int conteo = 1;
        int registro = 1;
        
        //Colas y pilas
        LinkedList cola = new LinkedList ();
        Stack pila = new Stack();
        LinkedList palindromo = new LinkedList ();
        LinkedList registroPal = new LinkedList ();
        
        
        //ciclo while para el menu
        while(x == true){
            respuesta = Integer.parseInt(JOptionPane.showInputDialog("**********REGISTRO DE PALABRAS – ESTRUCTURAS DE DATOS************"
                    + "\n1. Entregar ficha de atención"
                    + "\n2. Atender profesor"
                    + "\n3. Consultar si hay profesores pendientes de atención"
                    + "\n4. Reporte de totales de palabras"
                    + "\n5. Limpiar sistema"
                    + "\n6. Salir"
                    + "\nDigite la opción que desea ejecutar:"
                    + "\n****************************************************************"));

            
            //switch para pasar del menu a las opciones
            switch(respuesta){
                
                //opcion 1
                case 1:
                    //variables
                    String profesor = "";
                    int ciclo1 = 1;

                    //ciclo while para añadir a los  profes a una cola y al mismo tiemo darles su numero de ficha
                    while(ciclo1 == 1){
                        profesor = JOptionPane.showInputDialog("Su numero es el: " + conteo + ". Porfavor digite su nombre en el epacio");
                        cola.offer(conteo+ ". "+profesor);
                        conteo = conteo + 1;
                        
                        //ver si añadimos a otro
                        ciclo1 = Integer.parseInt(JOptionPane.showInputDialog("*****Desea entregar otra ficha?*****"
                                + "\n1. Si"
                                + "\n2. No"));                                      
                    }
                    
                    //finalizar ciclo
                    ciclo1 = 1;
                    break;

                    
                //opcion 2
                case 2:
                    int y = 1;
                    
                    //condicion para enumerar las palabras despues del delete
                    if (registro == 0 ){
                        registro = 1;
                    }
                    
                    //introducion con el profe
                    JOptionPane.showMessageDialog(null, "Buen dia " + cola.peekFirst());
                    
                    //ciclo while para las palabras 
                    while(y == 1){

                        palabra = JOptionPane.showInputDialog("Porfavor digite la palabra deaseada en el espacio para saber si es un palindromo ");
                        
                        //hago reverse para darle vuelat a las palabras
                        StringBuilder builder=new StringBuilder(palabra);
                        reversePal = builder.reverse().toString();


                        //if y else para verificar si las palabras son palindromas
                        if (reversePal.equals(palabra)){
                            JOptionPane.showMessageDialog(null, "La palabra si es un palindromo");
                            palindromo.offer(palabra+ " / " +cola.peekFirst());
                            registroPal.offer(registro +". "+palabra);
                            registro = registro+1;
                            
                        }else{
                            JOptionPane.showMessageDialog(null, "La palabra no es un palindromo");
                            pila.push(palabra);
                            registroPal.offer(registro +". "+palabra);
                            registro = registro+1;
                        }
                        
                        //ver si quiere probar más palabras
                        y = Integer.parseInt(JOptionPane.showInputDialog("*****Desea poner otra palabra?*****"
                                + "\n1. Si"
                                + "\n2. No"));
                        
                    }
                    
                   //terminar ciclo
                    cola.poll();
                    break;

                    
                //opcion 3
                case 3:
                    
                    //if para ver si hay profes pendientes
                    if (cola.peek()== null ){
                        JOptionPane.showMessageDialog(null, "No hay profesores pedientes ");
                    }else {
                        JOptionPane.showMessageDialog(null, "Los pendientes son: " + cola.peek());
                    }
                    break;

                //opcion 4
                case 4:
                    
                    //mostrar los registros 
                    JOptionPane.showMessageDialog(null, "El total de palabras es: " + registro);
                    JOptionPane.showMessageDialog(null, "El total de palabras palindromas son: " +palindromo);
                    JOptionPane.showMessageDialog(null, "El total de palabras no palindromas son: " + pila);
                    break;

                //opcion 5
                case 5:
                    
                    //imprimir las pilas y colas con las palabras
                    JOptionPane.showMessageDialog(null, "Las palabras normales son: " + pila);
                    JOptionPane.showMessageDialog(null, "Las palabras palindromas son: " +palindromo);
                    
                    //eliminar todo de las pilas y colas juto con el contador de las palabras
                    pila.clear();
                    palindromo.clear();
                    registro = 0;
                    break;

                    
                //finalizar programa terminando el ciclo while
                case 6:
                    JOptionPane.showMessageDialog(null, "Fin del programa");
                    x = false;
                    break;
            }
        }
    }
}
