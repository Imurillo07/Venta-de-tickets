package EstrDeDatos;

/**
 *
 * @author isaac
 */
import java.util.Scanner;

public class InfPer{
    String nombre = "";
    int cedula = 0;
    String correo = "";
    int tel = 0;
    
    void datos(){
        //teclado
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Porvafor digite su nombre completo");
        nombre = sc.nextLine();
        System.out.println("Porfavor digite su cedula de identidad con todos los ceros");
        cedula = sc.nextInt();
        System.out.println("Porfavor digite su correo electronico");
        correo = sc.nextLine();
        System.out.println("Porfavor digite su numero de telefono");
        tel = sc.nextInt();
    }
}
