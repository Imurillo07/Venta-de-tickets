package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class Conciertos {
        int Pvip = 200000;
        int Pgraderia = 50000;
        int Pplatea = 65000;
        int Pplaya = 65000;
        int Pcancha = 30000;
        
        ProTickets pro = new ProTickets();
        
    void BadBunny(){
        //variables
        int vip = 100;
        int graderia = 500;
        int platea = 600;
        int playa = 150;
        int cancha = 300;

        vip = vip - pro.Cvip;
        graderia = graderia - pro.Cgraderia;
        platea = platea - pro.Cplatea;
        playa = playa  - pro.Cplaya;    
        cancha = cancha - pro.Ccancha;
        
    }
    void Morat(){
        //variables
        int vip = 100;
        int graderia = 500;
        int platea = 600;
        int playa = 150;
        int cancha = 300;
        
        vip = vip - pro.Cvip;
        graderia = graderia - pro.Cgraderia;
        platea = platea - pro.Cplatea;
        playa = playa  - pro.Cplaya;    
        cancha = cancha - pro.Ccancha;

        
    }
    void ElCascanueces(){
        //variables
        int vip = 100;
        int graderia = 500;
        int platea = 600;
        int playa = 150;
        int cancha = 300;
        
        vip = vip - pro.Cvip;
        graderia = graderia - pro.Cgraderia;
        platea = platea - pro.Cplatea;
        playa = playa  - pro.Cplaya;    
        cancha = cancha - pro.Ccancha;

        
    }
    void LaOrquesta(){
        //variables
        int vip = 100;
        int graderia = 500;
        int platea = 600;
        int playa = 150;
        int cancha = 300;
        
        vip = vip - pro.Cvip;
        graderia = graderia - pro.Cgraderia;
        platea = platea - pro.Cplatea;
        playa = playa  - pro.Cplaya;    
        cancha = cancha - pro.Ccancha;
        
    }
}
