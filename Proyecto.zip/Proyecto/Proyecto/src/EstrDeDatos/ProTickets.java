package EstrDeDatos;

/**
 *
 * @author isaac
 */
import java.util.Scanner;

public class ProTickets {
    //teclado
    Scanner sc = new Scanner(System.in);
      
    //variables 
    int Cvip = 0;
    int Cgraderia = 0;
    int Cplatea = 0;
    int Cplaya = 0;
    int Ccancha = 0;
    int lugar = 0;
    String concierto = "";
    static int respuesta = 0;
    static boolean contarr = false;
    
    public static void main (String [] args) throws Exception{
        //variables
        boolean x = true;
        
        
        InfPer Info = new InfPer();
        Conciertos Con = new Conciertos();
        Factura Fact = new Factura();
        ProTickets pro = new ProTickets();
        Nodo1 nodo1 = new Nodo1();
        
        //teclado
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("---------------BIENVENIDOS---------------"
                + "\n---------------A ProTicket---------------"
                + "\n------------------MENU-------------------");
        
        System.out.print("Dale [ENTER] para continuar...");
        try
        {
          System.in.read();
          System.in.skip(System.in.available());
        }
        catch(Exception e){e.printStackTrace();}    
        
        int contador = 1;
        
        System.out.println("Que desea hacer?"
                + "\n1.Entrar a la cola"
                + "\n2.Salir de la cola"
                + "\n3.Atender");
        int res = sc.nextInt();
        if (res == 1){
            System.out.println("Bienvenido a la cola su numero es " + contador);
            nodo1.insertar(nodo1.cantidad()+1, contador);
        }if(res == 2){
            System.out.println("Digite el su numero en la cola");
            int salir = sc.nextInt();
            nodo1.extraer(salir);
        }if(res == 3){
            
        }
        
        while (x==true){
            
            System.out.println("Atendiendo al numero: ");// falta poner a quien se esta atendiendo
            System.out.println("---------Eliga el concierto al que desea comprar---------"
                    + "\n1.LA ORQUESTA FILARMONICA-PRESENTA LO MEJOR DE LUIS MIGUEL"
                    + "\n2.MORAT"
                    + "\n3.BAD BUNNY"
                    + "\n4.EL CASCANUECES 2022");
            respuesta = sc.nextInt();
            pro.saber();
            System.out.println("----------------------------------------------------------");
            switch(respuesta){
                case 1:

                    while (contarr == false){
                        pro.proceso();
                        pro.contar();

                        try{
                            Con.LaOrquesta();
                        }catch(Exception e) {
                            System.out.println("No hay tiquets suficientes, intente de nuevo");
                            break;
                        }
                    }
                    contarr = false;
                    Info.datos();
                    Fact.factura();
                    
                    break;
                case 2:
                    pro.proceso();
                    pro.contar();
                    try{
                        Con.Morat();
                    }catch(Exception e) {
                        System.out.println("No hay tiquets suficientes, intente de nuevo");
                        break;
                    }
                    Info.datos();
                    Fact.factura();
                    
                    break;
                    
                case 3:
                    pro.proceso();
                    pro.contar();
                    try{
                        Con.BadBunny();
                    }catch(Exception e) {
                        System.out.println("No hay tiquets suficientes, intente de nuevo");
                        break;
                    }
                    Info.datos();
                    Fact.factura();
                    
                    break;
                    
                case 4:
                     pro.proceso();
                    pro.contar();
                    try{
                        Con.ElCascanueces();
                    }catch(Exception e) {
                        System.out.println("No hay tiquets suficientes, intente de nuevo");
                        break;
                    }
                    Info.datos();
                    Fact.factura();
                    
                    break;
            }
     
        }  
    }
    void proceso(){
        System.out.println("Donde desea comprar?");
        boolean y = true;
        while(y == true){
            System.out.println("1.VIP"
                    + "\n2.graderia"
                    + "\n3.platea"
                    + "\n4.cancha"
                    + "\n5.playa"
                    + "\n6.volver");
            lugar = sc.nextInt();
            System.out.println("----------------------------------------------------------");
            System.out.println("");
            
            if (lugar==1){
                System.out.println("Cuantas entradas desea comprar?"
                        + "\n"
                        + "\nRecordar que solo se pueden comprar maximo 5 entradas en total pp");
                Cvip = sc.nextInt();
            }if(lugar == 2){
                System.out.println("Cuantas entradas desea comprar?"
                        + "\n"
                        + "\nRecordar que solo se pueden comprar maximo 5 entradas en total pp");
                Cgraderia = sc.nextInt();
            }if(lugar == 3){
               System.out.println("Cuantas entradas desea comprar?"
                        + "\n"
                        + "\nRecordar que solo se pueden comprar maximo 5 entradas en total pp");
                Cplatea = sc.nextInt();
            }if(lugar == 4){
                System.out.println("Cuantas entradas desea comprar?"
                        + "\n"
                        + "\nRecordar que solo se pueden comprar maximo 5 entradas en total pp");
                Ccancha = sc.nextInt();
            }if(lugar == 5){
                System.out.println("Cuantas entradas desea comprar?"
                        + "\n"
                        + "\nRecordar que solo se pueden comprar maximo 5 entradas en total pp");
                Cplaya = sc.nextInt();
            }if (lugar == 6){
                System.out.println("Volviendo al menu anterior");
                y = false;
            }
            System.out.println("----------------------------------------------------------");
        }
                    
    }
    void contar (){
       
        int Tentradas =  Cvip + Cgraderia + Cplatea + Cplaya + Ccancha;
        if (Tentradas > 5){
            System.out.println("NO es posible hacer la compra ya que tiene mas de 5 entradas");
            Cvip = 0;
            Cgraderia = 0;
            Cplatea = 0;
            Cplaya = 0;
            Ccancha = 0;
            lugar = 0;
            System.out.println("");
            System.out.println("Se han eliminado sus entradas porfavor vuelva a hacer el proceso");
            System.out.println("----------------------------------------------------------");
            
        }if (Tentradas <=5){
            System.out.println("Usted posee 5 o menos entradas, podemos continuar");
            System.out.println("----------------------------------------------------------");
            contarr = true;
        }
    }
    void saber (){
        if (respuesta ==1 ){
            concierto = "LA ORQUESTA FILARMONICA-PRESENTA LO MEJOR DE LUIS MIGUEL";
        }if (respuesta == 2){
            concierto = "MORAT";                   
        }if (respuesta == 3){
            concierto = "BAD BUNNY";
        }if (respuesta == 4){
            concierto = "EL CASCANUECES 2022";
        }
    }
}
 