/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;
import proyecto.AnadirProductos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** ULACIT
 * @author ximena perez, isaac murillo, caroline chaves 
 */
        
public class avanceFinal {
    public static void main (String [] xxpj){
        
        Scanner sc = new Scanner(System.in);
        System.out.println("");
 
        System.out.println("\t---------BIENVENIDOS A LA ZAPATERIA CIX---------");
        System.out.println("-------------------------------------------------------------------------------------------------");
        System.out.println("");
        
       
        
       System.out.println("");
        
//        avanceFinal cc = new avanceFinal();
//        cc.cierr();
//        cc.Menu();
    //VARIABLES
        float opcionn=0;
        

       //variable

       int opcion = 0;
       boolean x = true;




        System.out.println("-----------------------------------------");
        System.out.println("\tMENU PRINCIPAL");
        System.out.println("");
        System.out.println("1. Clientes");
        System.out.println("2. Disponibilidad de productos e inventario");
        System.out.println("3. Cierre de caja");
        System.out.println("4. Salir");
        System.out.println("");

        int yy =1;

        while (yy<2){
            System.out.println("");
            System.out.println("OPCIONES: 1. Clientes/ 2. Disponibilidad de productos e inventario /  3. Cierre de caja / 4. Salir");
            System.out.println("Digite el numero de la opcion que desea: ");
            opcion = sc.nextInt();
            System.out.println("");
            
            //VARIABLES DEL LOOP
            List<String> listaNom = new ArrayList<String>();
            String nombre="";
            String apellido="";
            String provincia="";
            String cedula="";
          
           

            

            if (opcion==1){
                System.out.println("Ha seleccionado la opcion 1");
                System.out.println("-----------------------------------------");
                System.out.println("");
             

                System.out.println("Favor ingresar datos de cliente");

                System.out.println("Ingrese el nombre: ");
                nombre= sc.nextLine();
                listaNom.add(nombre);

                System.out.println("Ingrese el apellido: ");
                apellido=sc.nextLine();      

                System.out.println("Ingrese la provincia en la que vive: ");
                provincia = sc.nextLine();


                System.out.println("Ingrese la cedula: ");
                cedula = sc.nextLine();

               
                
                 
                System.out.println("");
                System.out.println("\t---------------FACTURACION----------------");
                System.out.println("");
                System.out.println("DATOS CLIENTE:-----------------------");
                System.out.println("Nombre: " + nombre);
                System.out.println("Apellido: " + apellido);
                System.out.println("Cedula: " + cedula);
                System.out.println("Provincia: "+ provincia);
                System.out.println("");
                System.out.println("");
                System.out.println("PRODUCTOS:---------------------------");
            }
//-------------------------------------------------------PRODUCTOS--------------------------------------------------------------------------------------------------------

            if (opcion==2){
                System.out.println("Ha seleccionado la opcion de disponibilidad e inventario");
                System.out.println("-----------------------------------------");
                System.out.println("");
                Scanner EscXTeclado = new Scanner(System.in);
                AnadirProductos a  = new AnadirProductos();
                a.main(null);
   

                //listas
                
//                while (x){
//                    //menu entrada
//                    opcion = 0;
//
//                    System.out.println("-----------------------");
//                    System.out.println("Que desea hacer?");
//                    System.out.println("1. Sumar o restar inventario");
//                    System.out.println("2. Ver inventario");
//                    System.out.println("-----------------------");
//                    opcion = Integer.parseInt(sc.nextLine());
//                    if opcion == 1 {
//                        
//                    }


            }
        
        
//----------------------------------------------------------cierre de caja-------------------------------------------------------------------------------------------------------
            if (opcion==3){
                System.out.println("Ha seleccionado la opcion de facturacion");
                System.out.println("-----------------------------------------");
                System.out.println("");
                System.out.println("Lista de clientes: " +listaNom);
 

                System.out.println("TODOS LOS PRODUCTOS VENDIDOS EN EL DIA");
                // se agrega la lista de productos vendidos 

                System.out.println("GANANCIAS DEL DIA");
                // se agrega suma de ganancias 
            }
//--------------------------------------------------------------------------------------------------------------------------------------------------------------
           

            if (opcion==4){
                System.out.println("Se ha procedido a salir del sistema");
                System.out.println("-----------------------------------------");
                System.exit(yy);
                //salir de sistema

            }

            else{
                
                System.out.println("-----------------------------------------");
            }
        

    } 
    ////menu


 }
}
 
