package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class NodoLista {
    //variable en la cual se guarda el valor
    private String valor;
    
    //variable para enlazar nodos
    private NodoLista siguiente;
    
    //constructor que inicializamos el valor de las variables
    public void NodoEj2(){
        this.valor="";
        this.siguiente=null;
    }
    
    //metodos set y get de atributos
    public String getValor(){
        return valor;
    }
    public void setValor(String valor){
        this.valor=valor;
    }
    public NodoLista getSiguiente(){
        return siguiente;
    }
    public void setSiguiente(NodoLista siguiente){
        this.siguiente=siguiente;
    }
}
