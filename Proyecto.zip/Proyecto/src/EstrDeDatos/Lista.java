package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class Lista {
    
    private NodoLista inicio;
    private int size;
    
    public void Lista(){
        inicio=null;
        size=0;
    }
    
    public boolean esVacia(){
        return inicio==null;
    }
    
    public int getSize(){
        return size;
    }
    
    public void agregarAlFinal(String valor){

        NodoLista nuevo=new NodoLista();
        nuevo.setValor(valor);

        if(esVacia()){
            inicio=nuevo;
        }else{
            NodoLista aux=inicio;
            while(aux.getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        size++;
    }

    public void agregarAlInicio(String valor){
        NodoLista nuevo=new NodoLista();
        nuevo.setValor(valor);
        if(esVacia()){
            inicio=nuevo;
        }else{
            nuevo.setSiguiente(inicio);
            inicio=nuevo;
        }
        size++;
    }
    
public void insertarPorPosicion(int posicion, String valor) {

    if(posicion>=0 && posicion<=size) {
    NodoLista nuevo = new NodoLista();
    nuevo.setValor (valor);

    if (posicion == 0){
        nuevo.setSiguiente (inicio);
        inicio = nuevo;
    }
    else{
        if(posicion == size) {
            NodoLista aux = inicio;

            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux. setSiguiente (nuevo);
        }

            else{
                NodoLista aux = inicio;
                for (int i = 0; i < (posicion-1); i++) {
                   aux = aux.getSiguiente ();
                }
                NodoLista siguiente = aux.getSiguiente();
                aux.setSiguiente (nuevo);
                nuevo.setSiguiente (siguiente);
            }
        }
        size++;
    }
}

public String getValor(int posicion) throws Exception{
    if(posicion>=0 && posicion<size) {
        if (posicion == 0) {
            return inicio.getValor();
        }else{
            NodoLista aux = inicio;
            for (int i = 0; i < posicion; i++) {
                aux = aux. getSiguiente();
            }
            return aux.getValor();
        }
    } else {
        throw new Exception("Posicion inexistente en la lista.");
    }
}

    public boolean buscar(String referencia) {
    NodoLista aux = inicio;
    
    boolean encontrado = false;
    
    while(aux != null && encontrado != true) {
  
        if (referencia == aux.getValor()){
            encontrado = true;
        }
        else{
            aux = aux.getSiguiente();
        }
    }
    return encontrado;
}

public int getPosicion(String referencia) throws Exception{

    if (buscar(referencia)) {

        NodoLista aux = inicio;
        int cont = 0;

        while(referencia != aux.getValor()){
            cont ++;
            aux = aux.getSiguiente();
        }
        return cont;
    } else {
        throw new Exception("Valor inexistente en la lista.");
    }
}

public void editarPorPosicion(int posicion, String valor){

        if(posicion>=0 && posicion<size){
            
            if(posicion == 0){
                inicio.setValor(valor);
            }
            else{
                NodoLista aux = inicio;

                for(int i =0; i< posicion; i++){
                    aux = aux.getSiguiente();
                }
                aux.setValor(valor);
            }
        }
    }

  
    public void removerPorPosicion(int posicion){

        if(posicion>=0 && posicion<size){
            if(posicion == 0){
                inicio = inicio.getSiguiente();
            }else{
                NodoLista aux = inicio;
                
                for(int i = 0; i < posicion-1; i++){
                    aux = aux.getSiguiente();
                    NodoLista siguiente = aux.getSiguiente();
                    aux.setSiguiente(siguiente.getSiguiente());
                }
                size--;
            }
        }
    }

        public void eliminar(){
            inicio = null;
            size = 0;
        }

        public void listar(){

            if(!esVacia()){
                NodoLista aux = inicio;
                int i=0;

                while(aux !=null){
                    System.out.println(i +".[" + aux.getValor() + "]" + "->");
                    aux = aux.getSiguiente();
                    i++;
                }
            }
        }        
    }