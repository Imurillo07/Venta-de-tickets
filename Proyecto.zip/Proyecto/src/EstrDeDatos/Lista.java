package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class Lista {
    //puntero que indica el inicio de la lista(cabeza de la lista)
    private Nodo inicio;
    
    //variable para registrar el tamano de la lista
    private int size;
    
    //constructor por defecto
    public void Lista(){
        inicio=null;
        size=0;
    }
    //consulta si la lista esta vacia
    //devuyelve true si el primer nodod (inicio), no apunta a otro nodo
    public boolean esVacia(){
        return inicio==null;
    }
    //consulta de elementos en la lista (nodo)
    //devuelve numero entrero entre 0-n donde n es el numero de elementos que contenga la lista
    public int getSize(){
        return size;
    }
    //agreganuevo nodo al final de la lista
    public void agregarAlFinal(int valor){
        //define nuevo nodo
        Lista nuevo=new Lista();
        
        //agrega valor al nodo
        nuevo.setValor(valor);
        
        //consulta si la lista esta vacia
        if(esVacia()){
            //inicializa la lista agregando como inicio al nuevo nodo
            inicio=nuevo;
            //caso contrario recorre la lista hasta llegar el ultimo nodo y agreue el nodo
        }else{
            //crea copia de lista
            Nodo aux=inicio;
            //recorre la lista hasta llegar al ultimo nodo
            while(aux.getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            //agrega el nuevo nodo al final de la lista
            aux.setSiguiente(nuevo);
        }
        //incrementa el contador de tamano de la lista
        size++;
    }
    //agrega un nuevo nodo al inicio de la lista
    public void agregarAlInicio(int valor){
        //define nuevo nodo
        Lista nuevo=new Lista();
        
        //agrega valor al nodo
        nuevo.setValor(valor);
        
        //consulta si la lista esta vacia
        if(esVacia()){
            //inicializa la lista agregando como inicio al nuevo nodo
            inicio=nuevo;
            //caso contrario va agregando los nodos al incio de la lista
        }else{
            //une el nuevoi nodo con la lista existente
            nuevo.setSiguiente(inicio);
            
            //renombra al nuevo nodo como el inicio de la lista
            inicio=nuevo;
        }
        //incrementa tamano de la lista
        size++;
    }
    //insertar nuevo nodo despues de otro, ubicado por el valor que lo contiene
    public void insertarPorReferencia(int referencia, int valor){
        //def nuevo nodo
        Nodo nuevo=new Nodo();
        
        //agrega valor al nodo
        nuevo.setValor(valor);
        
        //verifica de si la lista contiene el elemento
        if(!esVacia()){
            //consulta si el valor existe en la lista
            if(buscar(referencia)){
                //crea copia de la lista
                Nodo aux=inicio;
                
                //recorre la lista hasta llegar al nodo de referencia
                while(aux.getValor()!=referencia){
                    aux=aux.getSiguiente();
                }
                //crea un respaldo de la continuacion de la lista
                Nodo siguiente=aux.getSiguiente();
                
                aux.setSiguiente(nuevo);
                
                //una de la continuacion de la lista al nuevo nodo
                nuevo.setSiguiente(siguiente);
                
                //incrementa tamano de la lista
                size++;
            }
        }
    }
    //Inserta un nuevo nodo despues en una posicién determinada.
public void insertarPorPosicion(int posicion, int valor) {
    //Verifica si la posicién ingresada se encuentre en el rango
    //f>= 0 y <= que el numero de elementos del la lista
    if(posicion>=0 && posicion<=size) {
    Nodo nuevo = new Nodo();
    nuevo.setValor (valor);

    //Consulte si el nuevo nodo a ingresar va al inicio de la lista.
    if (posicion == 0){
    //Inserta el nuevo nodo al inicio de la lista.
        nuevo.setSiguiente (inicio);
        inicio = nuevo;
    }
    else{

        //Si el nodo a inserta va al final de la lista.
        if(posicion == size) {
            Nodo aux = inicio;
        //Recorre la lista hasta llegar al ultimo nodo
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            //Inserta 21 nuevo nodo despues de del ultimo.
            aux. setSiguiente (nuevo);
        }

            else{
                //Si el node a insertar va en el medio de la lista.
                Nodo aux = inicio;
                //Recorre la lista hasta llegar al nodo anterior
                //a la posicion en la cual se insertara el nuevo nodo.
                for (int i = 0; i < (posicion-1); i++) {
                   aux = aux.getSiguiente ();
                }
                //Guarda el nodo siguiente al nodo en la posicién
                //en la cual va a insertar el nevo nodo.
                Nodo siguiente = aux.getSiguiente();
                //Inserta el nuevo nodo en la posicidn indicada.
                aux.setSiguiente (nuevo);
                //Une el nuevo nodo con el resto de la lista.

                nuevo.setSiguiente (siguiente);
            }
        }

        //Incrementa el contador de tamafio de la lista.

        size++;
    }
}

//Obtiene el valor de un nodo en una determinada posicién.
public int getValor(int posicion) throws Exception{
    //Vexifica si la posicién ingresada se encuentre en el rango
    //>= 0 y < que el numero de elementos del la lista.
    if(posicion>=0 && posicion<size) {
        //Consulta si la posicion es el inicio de la lista.
        if (posicion == 0) {
            //Retorna el valor del inicio de la lista.
            return inicio.getValor();
        }else{
            //Crea una copia de la lista.
            Nodo aux = inicio;
            //Recorre la lista hasta la posicién ingresada.
            for (int i = 0; i < posicion; i++) {
                aux = aux. getSiguiente();
            }
            //Retorna el valor del nodo.
            return aux.getValor();
        }
    //Crea una excepcién de Posicion inexistente en la lista.
    } else {
        throw new Exception("Posicion inexistente en la lista.");
    }
}
//Busca si existe un valor en la lista.
    public boolean buscar(int referencia) {
    //Cxea una copia de la lista.
    Nodo aux = inicio;
    //Bandera para indicar si el valor existe.
    boolean encontrado = false;
    //Recorre la lista hasta encontrar el elemento o hasta
    //llegar al final de la lista.
    while(aux != null && encontrado != true) {
    //Consulta si el valor del nodo es igual al de referencia.
        if (referencia == aux.getValor()){
            //Canbia e1 valor de la bandera.
            encontrado = true;
        }
        else{
            //Avansa al siguiente. nodo.
            aux = aux.getSiguiente();
        }
    }
    //Retorna el resultado de la bandera.
    return encontrado;
}
//Consulta la posicién de un elemento en la lista
public int getPosicion(int referencia) throws Exception{
    //Consulta si el valor existe en la lista.
    if (buscar(referencia)) {
        //Crea una copia de la lista.
        Nodo aux = inicio;
        //COntado para almacenar la posicién del nodo.
        int cont = 0;
        //Recoore la lista hasta llegar al nodo de referencia.
        while(referencia != aux.getValor()){
            //Incrementa el contador.
            cont ++;
            //Avansa al siguiente. nodo.
            aux = aux.getSiguiente();
        }
        //Retorna el valor del contador.
        return cont;
    //Crea una excepcién de Valor inexistente en la lista.
    } else {
        throw new Exception("Valor inexistente en la lista.");
    }
}
//Retualiza el valor de un nodo que se encuentre ubicado en la lista
public void editarPorReferencia(int referencia, int valor) {
    //Consulta si el valor existe en la lista.
    if (buscar(referencia)) {
        //Crea ua copia de la lista.
        Nodo aux = inicio;
        //Recorre la lista hasta llegar al nodo de referencia.
        while (aux.getValor() != referencia) {
            aux = aux.getSiguiente () ;
        }
        //Aetualizamos el valor del nodo
        aux.setValor(valor);
    }
}
public void editarPorPosicion(int posicion, int valor){
        // Verifica si la posicion ingresada se encuentra en el rango 
        // >= 0 y < que el numero de elementos en la lista.
        
        if(posicion>=0 && posicion<size){
            //Consulta si el nodo a eliminar es el primero.
            if(posicion == 0){
                // Actualiza el valor del primer nodo.
                
                inicio.setValor(valor);
            }
            else{
                // En caso de que el nodo a eliminar este por el medio o sea el ultimo 
                Nodo aux = inicio;
                //Recorre la lista hasta llegar al nodo anterior al eliminar.
                for(int i =0; i< posicion; i++){
                    aux = aux.getSiguiente();
                }
                // Actualiza el valor del nod 
                aux.setValor(valor);
            }
        }
    }
    // Elimina un nodo que se encuentre en la lista ubicado 
    public void removerPorReferencia(int referencia){
        // Consulta si el valor de referncia existe en la lista
        if(buscar(referencia)){
            //Consulta si el nodo a eliminar es el primero
            if(inicio.getValor() == referencia){
                inicio = inicio.getSiguiente();
            }else {
                //Crea una copia de la lista 
                Nodo aux = inicio;
                //Recorre la lista hasta llegar al nodo anterior
                // al de referencia 
                
                while(aux.getSiguiente().getValor() != referencia){
                    aux = aux.getSiguiente();
                }
                //Guarda el nodo siguiente del nodo a elimianr
                Nodo siguiente = aux.getSiguiente().getSiguiente();
                //Enlaza el nodo anterior al de eliminar con el siguiente despued de el 
                aux.setSiguiente(siguiente);
            }
            //Disminuye el contador de tamano de la lista 
            size--;
        }
    }
    public void removerPorPosicion(int posicion){
        //Verifica si la posicion ingresada se encuentre en el rango 
        //>=0 y <que el numero de elementos de la lista 
        if(posicion>=0 && posicion<size){
            //Consulta si el nodo a eliminar es el primero
            if(posicion == 0){
                // Elimina el primero nodo apuntando al siguiente
                inicio = inicio.getSiguiente();
            }
            //En caso que el nodo a eliminar este por el medio o sea el ultimo
            else{
                //Crea una copia de la lista
                Nodo aux = inicio;
                //Recoree la lista hasta llegar al nodo anterior al eliminar
                for(int i = 0; i < posicion-1; i++){
                    aux = aux.getSiguiente();
                    //Guarda el nodo siguiente al nodo a eliminar
                    Nodo siguiente = aux.getSiguiente();
                    //Elimina la referencia del nodo auntando al nodo siguiente
                    aux.setSiguiente(siguiente.getSiguiente());
                }
                //Dismunye el contado de tamno de la lizta 
                size--;
            }
        }
    }
        //Elimina la lista 
        public void eliminar(){
            // Elimina el valor y la referencia a los demas nodos
            inicio = null;
            //Reinicia el contador de taman de la lista a 0
            size = 0;
        }
        // Muestra en pantalla los elementos de la lista
        public void listar(){
            //Verifica si la lista contiene elementos 
            if(!esVacia()){
                Nodo aux = inicio;
                //Posicion de los elementos de la lista 
                int i=0;
                //Recorre la lista hasta el final
                while(aux !=null){
                    //Imprime en la pantalla el valor del nodo
                    System.out.println(i +".[" + aux.getValor() + "]" + "->");
                    //Avanza al siguiente nodo
                    aux = aux.getSiguiente();
                    //Incrementa el contador de la posicion
                    i++;
                }
            }
        }
        
    }