package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class Factura extends ProTickets{
    static int TOTAL = 0;
    static int TotalE = 0;
    static int Total = 0;
    static int TOTALE = 0;
    
    void factura(){
        Conciertos Con = new Conciertos();
        ProTickets pro = new ProTickets();
        InfPer Info = new InfPer();
        Cola cola = new Cola ();
        Lista lista = new Lista();
        Pila pila = new Pila ();
        
        int TPvip = Con.Pvip * pro.Cvip ;
        int TPplaya = Con.Pplaya * pro.Cplaya;
        int TPcancha = Con.Pcancha * pro.Ccancha;
        int TPgraderia = Con.Pgraderia * pro.Cgraderia;
        int TPplatea = Con.Pplatea * pro.Cplatea;
        TotalE = pro.Cvip + pro.Cplaya + pro.Ccancha + pro.Cgraderia + pro.Cplatea;
        Total = TPvip + TPplaya + TPcancha + TPgraderia + TPplatea;
        
        
        System.out.println("--------------Gracias Por Comprar--------------"
                + "\n---------------ProTicket---------------");
        System.out.println("Entradas para el concierto " + pro.concierto );
        System.out.println("Factura del numero: ");
        //cola.primero();
        System.out.println("");
        System.out.println("Cliente: " + Info.nombre);
        System.out.println("Cedula: " + Info.cedula);
        System.out.println("Correo: " + Info.correo);
        System.out.println("Telefono: " + Info.tel);
        System.out.println("");
        System.out.println("Entradas VIP                         " + pro.Cvip + "   Valor " + TPvip);
        System.out.println("");
        System.out.println("Entradas Playa                       " + pro.Cplaya + "   Valor " + TPplaya);
        System.out.println("");
        System.out.println("Entradas Cancha                      " + pro.Ccancha + "   Valor " + TPcancha);
        System.out.println("");
        System.out.println("Entradas graderia                    " + pro.Cgraderia + "   Valor " + TPgraderia);
        System.out.println("");
        System.out.println("Entradas Platea                      " + pro.Cplatea + "   Valor " + TPplatea);
        System.out.println("");
        System.out.println("En total se compraron " + TotalE + " con el monto total de " + Total);
        System.out.println("================Gracias por elegirnos================");
        
        TOTAL = Total + TOTAL;
        TOTALE = TotalE + TOTALE;
     
        cola.borrar(1);
        pila.insertar(Info.nombre);
        String list = Info.nombre + "=>" + TOTAL;
        lista.agregarAlFinal(list);
        
    }
    public void Tentradas(){
        System.out.println(TOTALE);
    }
    public void Ttotal(){
        System.out.println(TOTAL);
    }
}
