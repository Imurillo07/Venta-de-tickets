package EstrDeDatos;

/**
 *
 * @author isaac
 */
import java.util.Scanner;

public class ProTickets {
    //teclado
    Scanner sc = new Scanner(System.in);
      
    //variables 
    static int Cvip = 0;
    static int Cgraderia = 0;
    static int Cplatea = 0;
    static int Cplaya = 0;
    static int Ccancha = 0;
    static int lugar = 0;
    static String concierto = "";
    static int respuesta = 0;
    static boolean contarr = false;
    
    public static void main (String [] args) throws Exception{
        //variables
        boolean x = true;
        
        
        InfPer Info = new InfPer();
        Conciertos Con = new Conciertos();
        Factura Fact = new Factura();
        ProTickets pro = new ProTickets();
        Cola cola = new Cola();
        Pila pila = new Pila();
        Lista lista = new Lista();
        Cierre cierre = new Cierre();
        
        //teclado
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        
        
        System.out.println("---------------BIENVENIDOS---------------"
                + "\n---------------A ProTicket---------------"
                + "\n------------------MENU-------------------");
        
        System.out.print("Dale [ENTER] para continuar...");
        try
        {
          System.in.read();
          System.in.skip(System.in.available());
        }
        catch(Exception e){e.printStackTrace();}    
        
        int contador = 1;
        boolean j = true;
        
        while (j == true){
            System.out.println("----------Que desea hacer?----------"
                    + "\n1.Entrar a la cola"
                    + "\n2.Admin Colas"
                    + "\n3.Atender"
                    + "\n4.Pilas"
                    + "\n5.Lista"
                    + "\n6.Cerrar caja"
                    + "\n7.salir");
            int res = sc.nextInt();
            
            switch (res){
                case 1:
                    System.out.println("Bienvenido a la cola su numero es " + contador);
                    cola.insertar(cola.cantidad()+1, contador);
                    contador = contador + 1;
                    break;
                    
                case 2:
                    
                    boolean c = true;
                    while (c == true){
                        System.out.println("----------Que desea hacer?----------"
                                + "\n1.Salir de la cola"
                                + "\n2.Cantidad"
                                + "\n3.Vacia"
                                + "\n4.Vaciar"
                                + "\n5.Volver");
                        int r = sc2.nextInt();
                        
                        switch (r){
                            
                            case 1:
                                System.out.println("Digite el su numero en la cola");
                                int salir = sc.nextInt();
                                cola.extraer(salir);
                                break;
                               
                            case 2:
                                System.out.println("Hay " + cola.cantidad() + " personas en la  cola" );

                                break;
                                
                            case 3:
                                System.out.println("La cola esta vacia: " + cola.vacia());
                                break;
                                
                            case 4:
                                cola.vaciar();
                                System.out.println("La cola esta vacia: " + cola.vacia());
                                break;
                                
                            case 5:
                                c = false;
                                break;
                        }
                    }
                      
                    
                case 3:
                    while (x==true){
                        
                        try{
                            System.out.print("Atendiendo al numero: ");
                            cola.primero();
                            System.out.println("---------Eliga el concierto al que desea comprar---------"
                                    + "\n1.LA ORQUESTA FILARMONICA-PRESENTA LO MEJOR DE LUIS MIGUEL"
                                    + "\n2.MORAT"
                                    + "\n3.BAD BUNNY"
                                    + "\n4.EL CASCANUECES 2022");
                            respuesta = sc.nextInt();
                            pro.saber();
                            System.out.println("----------------------------------------------------------");
                            switch(respuesta){
                                case 1:

                                    while (contarr == false){
                                        pro.proceso();
                                        pro.contar();

                                        try{
                                            Con.LaOrquesta();
                                        }catch(Exception e) {
                                            System.out.println("No hay tiquets suficientes, intente de nuevo");
                                            break;
                                        }
                                    }
                                    contarr = false;
                                    Info.datos();
                                    Fact.factura();

                                    break;
                                case 2:
                                    pro.proceso();
                                    pro.contar();
                                    try{
                                        Con.Morat();
                                    }catch(Exception e) {
                                        System.out.println("No hay tiquets suficientes, intente de nuevo");
                                        break;
                                    }
                                    Info.datos();
                                    Fact.factura();

                                    break;

                                case 3:
                                    pro.proceso();
                                    pro.contar();
                                    try{
                                        Con.BadBunny();
                                    }catch(Exception e) {
                                        System.out.println("No hay tiquets suficientes, intente de nuevo");
                                        break;
                                    }
                                    Info.datos();
                                    Fact.factura();

                                    break;

                                case 4:
                                    pro.proceso();
                                    pro.contar();
                                    try{
                                        Con.ElCascanueces();
                                    }catch(Exception e) {
                                        System.out.println("No hay tiquets suficientes, intente de nuevo");
                                        break;
                                    }
                                    Info.datos();
                                    Fact.factura();
                                    x = false;
                                    break;
                            }

                        }catch(Exception e) {
                            System.out.println("No hay nadie a quien atender");
                        }
                        break;
                    }
                    
                
                case 4:
                    boolean p = true;
                    int pil = 0;
                    while (p == true){
                        System.out.println("----------Que desea hacer?----------"
                                + "\n1.Vizualizar pila"
                                + "\n2.Buscar elemento en la pila"
                                + "\n3.Anadir elemento a la pila"
                                + "\n4.Quitar ultimo elemento de la pila"
                                + "\n5.Salir");
                        pil = sc.nextInt();
                        
                        switch(pil){
                            case 1:
                                System.out.println("-------------------------------------");
                                pila.visualizarpila();
                                break;
                                
                            case 2:
                                System.out.println("-------------------------------------");
                                pila.buscarelemento();
                                break;
                                
                            case 3:
                                System.out.println("-------------------------------------");
                                System.out.println("digite el elemento que desea anadir");
                                String a = sc2.nextLine();
                                pila.insertar(a);
                                break;
                                
                            case 4:
                                pila.elimUlt();
                                break;
                                
                            case 5:
                                p = false;
                                break;
                        }
                    }
                    break;
                    
                case 5:
                    boolean b = true;
                    String agregar = "";
                    int lis = 0;
                    while (b == true){
                        System.out.println("----------Que desea hacer?----------"
                                + "\n1.Agregar a la lista"
                                + "\n2.Sacar de la lista"
                                + "\n3.Buscar"
                                + "\n4.Imprimir"
                                + "\n5.Vaciar"
                                + "\n6.Salir");
                        lis = sc.nextInt();
                        
                        switch(lis){
                            
                            case 1:
                                System.out.println("----------Que desea hacer?----------"
                                        + "\n1.Agregar al final"
                                        + "\n2.Agregar al inicio"
                                        + "\n3.Agregar por posicion"
                                        + "\n4.volver");
                                int e = sc1.nextInt();
                                
                                if (e == 1){
                                    System.out.println("Que desea agregar al final?");
                                    agregar = sc2.nextLine();
                                    lista.agregarAlFinal(agregar);
                                }
                                
                                if (e == 2){
                                    System.out.println("Que desea agregar al inicio?");
                                    agregar = sc2.nextLine();
                                    lista.agregarAlInicio(agregar);
                                }
                                
                                if (e == 3){
                                    System.out.println("Que desea agregar por posicion?");
                                    agregar = sc2.nextLine();
                                    System.out.println("Digite la posicion en la que lo desea insertar");
                                    int pos = sc1.nextInt();
                                    lista.insertarPorPosicion(pos, agregar);
                                }
                                if (e == 4){
                                    break;
                                }
                                break;
                                
                            case 2:
                                System.out.println("Digite la poscicion del valor que desea sacar de la lista");
                                int pos = sc1.nextInt();
                                lista.removerPorPosicion(pos);                              
                                break;
                                
                            case 3:
                                System.out.println("Digite lo que desea buscar");
                                String busc = sc1.nextLine();
                                System.out.print("El ducumento esta en la lista: ");
                                lista.buscar(busc);
                                break;
                                
                            case 4:
                                lista.listar();
                                break;
                                
                            case 5:
                                System.out.println("Vaciando Lista");
                                lista.eliminar();
                                System.out.println("Lista vacia");
                                break;
                                
                            case 6:
                                b = false;
                                break;
                        }
                        
                    }
                    break;
                
                case 6:
                    cierre.Cierre();
                    break;
                    
                case 7:
                    j = false;
                    break;
                    
            }
        }
        
        System.out.println("================Gracias por elegirnos================");
    }
                
                
    void proceso(){
        System.out.println("Donde desea comprar?");
        boolean y = true;
        while(y == true){
            System.out.println("1.VIP"
                    + "\n2.graderia"
                    + "\n3.platea"
                    + "\n4.cancha"
                    + "\n5.playa"
                    + "\n6.continuar");
            lugar = sc.nextInt();
            System.out.println("----------------------------------------------------------");
            System.out.println("");
            
            if (lugar==1){
                System.out.println("Recordar que solo se pueden comprar maximo 5 entradas en total p/p"
                        + "\n"
                        + "\nCuantas entradas desea comprar?");
                Cvip = sc.nextInt();
            }if(lugar == 2){
                System.out.println("Recordar que solo se pueden comprar maximo 5 entradas en total p/p"
                        + "\n"
                        + "\nCuantas entradas desea comprar?");
                Cgraderia = sc.nextInt();
            }if(lugar == 3){
               System.out.println("Recordar que solo se pueden comprar maximo 5 entradas en total p/p"
                        + "\n"
                        + "\nCuantas entradas desea comprar?");
                Cplatea = sc.nextInt();
            }if(lugar == 4){
                System.out.println("Recordar que solo se pueden comprar maximo 5 entradas en total p/p"
                        + "\n"
                        + "\nCuantas entradas desea comprar?");
                Ccancha = sc.nextInt();
            }if(lugar == 5){
                System.out.println("Recordar que solo se pueden comprar maximo 5 entradas en total p/p"
                        + "\n"
                        + "\nCuantas entradas desea comprar?");
                Cplaya = sc.nextInt();
            }if (lugar == 6){
                System.out.println("Continuando con la compra");
                y = false;
            }
            System.out.println("----------------------------------------------------------");
        }
                    
    }
    void contar (){
       
        int Tentradas =  Cvip + Cgraderia + Cplatea + Cplaya + Ccancha;
        if (Tentradas > 5){
            System.out.println("NO es posible hacer la compra ya que tiene mas de 5 entradas");
            Cvip = 0;
            Cgraderia = 0;
            Cplatea = 0;
            Cplaya = 0;
            Ccancha = 0;
            lugar = 0;
            System.out.println("");
            System.out.println("Se han eliminado sus entradas porfavor vuelva a hacer el proceso");
            System.out.println("----------------------------------------------------------");
            
        }if (Tentradas <=5){
            System.out.println("Usted posee 5 o menos entradas, podemos continuar");
            System.out.println("----------------------------------------------------------");
            contarr = true;
        }
    }
    void saber (){
        if (respuesta ==1 ){
            concierto = "LA ORQUESTA FILARMONICA-PRESENTA LO MEJOR DE LUIS MIGUEL";
        }if (respuesta == 2){
            concierto = "MORAT";                   
        }if (respuesta == 3){
            concierto = "BAD BUNNY";
        }if (respuesta == 4){
            concierto = "EL CASCANUECES 2022";
        }
    }
}
 