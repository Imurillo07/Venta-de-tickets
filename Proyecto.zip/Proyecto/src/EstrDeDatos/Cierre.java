package EstrDeDatos;

/**
 *
 * @author isaac
 */
public class Cierre {
    public void Cierre(){
        Factura fact = new Factura();
        Lista lista = new Lista();
        Cola cola = new Cola();
        Pila pila = new Pila ();
        
       
        System.out.println("El total de tiquetes vendidos fueron: ");
        fact.Tentradas();
        
        System.out.println("El total vendido fue: ");
        fact.Ttotal();
        
        System.out.println("Los clientes del dia fueron: ");
        lista.listar();
        
        lista.eliminar();
        cola.vaciar();
        pila.vaciar();
    }

}
