package EstrDeDatos;

import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author isaac
 */
public class Pila {
    static Stack <String> pila = new Stack <String>();

    public void insertar (String x){
        pila.push(x);
    }
    
    public void elimUlt (){
        pila.pop();
    }
    
    public void visualizarpila(){
        System.out.println("Los elementos de la pila son: " + pila);
        System.out.println("La pila esta vacia?: " + pila.empty());
        System.out.println("El tamano de la pila es: " + pila.size());
    }

    public void buscarelemento(){
        Scanner leer= new Scanner (System.in);
        System.out.println("Ingrese el dato a buscar: ");
        String elemento = leer.nextLine();
        if(pila.search(elemento) == -1){
            System.out.println("El dato no se encuentra en la pila");
            
        }else{
            System.out.println("El elemento se encuentra en la posicion: " + pila.search(elemento));
        }
              
    }
    
    public void vaciar(){
        pila.clear();
    }
   
}